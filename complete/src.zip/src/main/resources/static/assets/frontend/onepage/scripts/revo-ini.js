jQuery(document).ready(function() {
      revapi = jQuery('.tp-banner').show().revolution({
        delay: 000,
        startwidth: 1170,
        startheight: 500,
        hideThumbs: true,
        fullWidth: "off",
        fullScreen: "on",
        touchenabled: "off",
        fullScreenOffsetContainer: ""
      });
    });